
import Todo from "../models/Todo.js";

export const getTodos = async (req, res) => {

    try {

        const todos = await Todo.find();

        res.json(todos);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

};

export const createTodo = async (req, res) => {

    try {

        const todo = await Todo.create({
            text: req.body.text
        });

        res.status(201).json(todo);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

};

export const updateTodo = async (req, res) => {

    try {

        const todo = await Todo.findByIdAndUpdate(

            req.params.id,

            req.body,

            {
                new: true
            }

        );

        res.json(todo);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

};

export const deleteTodo = async (req, res) => {

    try {

        await Todo.findByIdAndDelete(req.params.id);

        res.json({
            message: "Todo Deleted"
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

};