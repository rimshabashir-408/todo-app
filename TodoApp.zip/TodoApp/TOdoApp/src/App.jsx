import { useState, useEffect } from 'react'
import axios from "axios";


const API = "http://localhost:5000/api/todos";


function App() {
  const [task, setTask] = useState('')
  const [todos, setTodos] = useState([])


useEffect(() => {

    getTodos();

}, []);

const getTodos = async () => {

    const res = await axios.get(API);

    setTodos(res.data);

};










  // useEffect(() => {
  //   const savedTodos = JSON.parse(localStorage.getItem('todos')) || []
  //   setTodos(savedTodos)
  // }, [])

  // useEffect(() => {
  //   localStorage.setItem('todos', JSON.stringify(todos))
  // }, [todos])

  // const addTodo = () => {
  //   if(task.trim() === '') return
  //   const newTodo = { id: Date.now(), text: task, completed: false }
  //   setTodos([...todos, newTodo])
  //   setTask('')
  // }

  // const deleteTodo = (id) => {
  //   setTodos(todos.filter((todo) => todo.id!== id))
  // }

  // const toggleComplete = (id) => {
  //   setTodos(todos.map((todo) =>
  //     todo.id === id? {...todo, completed:!todo.completed } : todo
  //   ))
  // }


  // add todo
const addTodo = async () => {

    if (!task.trim()) return;

    await axios.post(API, {

        text: task

    });

    getTodos();

    setTask("");

};

// Delete Todo
const deleteTodo = async (id) => {

    await axios.delete(`${API}/${id}`);

    getTodos();

};


// Toggle Complete
const toggleComplete = async (id, completed) => {

    await axios.put(`${API}/${id}`, {

        completed: !completed

    });

    getTodos();

};



  const handleKeyPress = (e) => {
    if(e.key === 'Enter') addTodo()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-lg">

        <h1 className="text-4xl font-bold text-center mb-2 text-gray-800">
          📝 Todo App
        </h1>
        <p className="text-center text-gray-500 mb-6">Track Your Task!</p>

        <div className="flex gap-2 mb-6">
          <input
            type="text"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Enter your Task..."
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-purple-500 transition"
          />

          <button
            onClick={addTodo}
            className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-6 py-3 rounded-lg transition shadow-md"
          >
            Add
          </button>
        </div>

        <ul className="space-y-3 max-h-96 overflow-y-auto">
          {todos.map((todo) => (
            <li
              key={todo._id}
              className="flex items-center justify-between bg-gray-50 p-4 rounded-lg hover:shadow transition"
            >
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => toggleComplete(todo._id)}
                  className="w-5 h-5 accent-purple-600 cursor-pointer"
                />
                <span className={`text-gray-800 ${todo.completed? 'line-through text-gray-400' : ''}`}>
                  {todo.text}
                </span>
              </div>

              <button
                onClick={() => deleteTodo(todo._id)}
                className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm transition"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>

        {todos.length === 0 && (
          <p className="text-center text-gray-400 mt-6">No Task Yet</p>
        )}

        {todos.length > 0 && (
          <p className="text-center text-gray-500 mt-4 text-sm">
            Total: {todos.length} | Complete: {todos.filter(t => t.completed).length}
          </p>
        )}

      </div>
    </div>
  )
}

export default App